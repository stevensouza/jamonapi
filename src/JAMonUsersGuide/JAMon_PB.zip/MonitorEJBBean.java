package mis.fss.gsa.gov;


import com.jamonapi.*;
import java.io.*;
import javax.ejb.*;


public class MonitorEJBBean extends java.lang.Object implements javax.ejb.SessionBean,javax.ejb.SessionSynchronization {
    protected boolean create() throws java.lang.Exception     {
        return true;
    }

    public MonitorEJBBean()     { 
    }

    private void unhandledEvent( String listenerName, String methodName, java.lang.Object event )     {
    }

    public void ejbActivate() throws javax.ejb.EJBException, java.rmi.RemoteException     {
    }

    public void ejbPassivate() throws javax.ejb.EJBException, java.rmi.RemoteException     {
    }

    public void ejbRemove() throws javax.ejb.EJBException, java.rmi.RemoteException     {
    }

    public void setSessionContext( javax.ejb.SessionContext parm0 ) throws javax.ejb.EJBException, java.rmi.RemoteException     {
        this._sessionContext = parm0;		
    }

    public void afterBegin() throws javax.ejb.EJBException, java.rmi.RemoteException     {
    }

    public void afterCompletion( boolean parm0 ) throws javax.ejb.EJBException, java.rmi.RemoteException     {
    }

    public void beforeCompletion() throws javax.ejb.EJBException, java.rmi.RemoteException     {
    }

    private javax.ejb.SessionContext _sessionContext;


    public void ejbCreate() throws javax.ejb.EJBException, javax.ejb.CreateException     {
        try {
            create();   // This 'create()' is used for internal initialization.
        }
        catch( java.lang.Exception __e) {
            System.err.println( __e.toString() + " " + __e.getMessage() );
        }
    }


    public String[][] getData() throws javax.ejb.EJBException     {
        try{
            return MonitorFactory.getRootMonitor().getData();
        }
        catch (Exception e)
        {
            throw getEJBException(e);
        }
    }

    private EJBException getEJBException(Exception e)     {
        StringWriter sw=new StringWriter();
        e.printStackTrace(new PrintWriter(sw));

        return new EJBException(sw.toString());
    }


    public String getReport() throws javax.ejb.EJBException     {
       try {
            return MonitorFactory.getReport();

        }
        catch (Exception e)
        {
            throw getEJBException(e);
        }

    }


    public String getTabDelimitedData() throws javax.ejb.EJBException     {
      try{
        StringBuffer table=new StringBuffer(20000);

        // Create report body        
        String[][] data=MonitorFactory.getRootMonitor().getData();
        int rows=data.length;
        int cols=data[0].length;

        for (int i=0; i<rows; i++)
           {
             for (int j=0; j<cols; j++) {
                table.append(data[i][j]);
                if (j<=cols-1)
                    table.append("\t");
             }

             table.append("\r\n");
           }

        return table.toString();
       }
       catch (Exception e)
       {
            throw getEJBException(e);
       }

    }

    private void log(Object obj)     {
        System.out.println(obj.toString());
    }

    public void reset() throws javax.ejb.EJBException     {
        MonitorFactory.reset();
    }

    public void start(String locator) throws javax.ejb.EJBException     {
        mon=MonitorFactory.start(locator);
    }

    public void stop() throws javax.ejb.EJBException     {
        log(mon.stop());
    }

    Monitor mon;
}

