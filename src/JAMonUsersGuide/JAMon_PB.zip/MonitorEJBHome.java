package mis.fss.gsa.gov;


public interface MonitorEJBHome extends javax.ejb.EJBHome {

    public MonitorEJB create() throws java.rmi.RemoteException;
}

