package mis.fss.gsa.gov;


public interface MonitorEJB extends javax.ejb.EJBObject {

    public void start(String locator) throws java.rmi.RemoteException;

    public void stop() throws java.rmi.RemoteException;

    public String getReport() throws java.rmi.RemoteException;

    public void reset() throws java.rmi.RemoteException;
}

