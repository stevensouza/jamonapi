package com.jamonapi;

/** Interface used to return info from a monitor.  Primarily will be used in the JAMonBufferListener
 *  class.
 *  
 * @author steve souza
 *
 */
public interface JAMonDetailRow {
  public Object[] getJAMonDetailRow();
}
