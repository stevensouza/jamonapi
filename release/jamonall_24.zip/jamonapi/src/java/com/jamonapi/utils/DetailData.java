package com.jamonapi.utils;

public interface DetailData {
	
	public String[] getHeader();
	public Object[][] getData();

}
