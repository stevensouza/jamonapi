package com.jamonapi.utils;

/** Interface for array tabular data */
public interface DetailData {
	
	public String[] getHeader();
	public Object[][] getData();
//    public boolean hasData();
//    public boolean isEmpty();
//    public int getRowCount();

}
