package com.jamonapi;

public class NullMonitor extends MonitorImp {
    
    public NullMonitor() {
        disable();
    }
    
}
